EyeRig V16 — Rounded Guide Rail Print Set

V16 only smooths the guide-rail interfaces. All critical V15 mounting logic is preserved.

Changes:
- X rails on Main Plate: 8.0 mm wide × 2.0 mm high, top two longitudinal edges rounded R0.8 mm.
- Y rails on Fixed Y Plate: same 8.0 × 2.0 mm profile, exposed tip corners rounded R0.8 mm.
- X and Y grooves remain 9.2 mm wide × 2.4 mm deep.
- Each groove mouth receives a simple 0.6 mm 45-degree lead-in chamfer; this is not a dovetail or undercut.
- Nominal side clearance remains 0.60 mm per side; depth clearance remains 0.40 mm.

Why not make the rails fully semicircular:
- A fully round rail would reduce the straight sidewall that resists yaw.
- R0.8 removes the sharp corners while retaining ~1.2 mm of straight guiding sidewall.
- The geometry remains support-free and easy to print.

Unchanged from V15:
- M6 locking scheme and 50 mm two-screw spacing.
- X stage has only M6 through-holes; no X captive nut pockets.
- Y moving plate keeps its front-side captive M6 nuts.
- DCA1000 / IWR1443 / IR camera mounting interfaces.
- Main Plate speaker-stand holes.
- Low-overhang Chin Support.
- X/Y travel ±40 mm.

Recommended first print:
00_ROUNDED_GUIDE_FIT_COUPON_V16.stl
