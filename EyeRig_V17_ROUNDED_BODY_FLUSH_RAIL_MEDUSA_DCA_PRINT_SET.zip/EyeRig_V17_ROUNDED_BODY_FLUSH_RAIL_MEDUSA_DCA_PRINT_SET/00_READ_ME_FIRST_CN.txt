EyeRig V17 — Rounded Body / Flush Rail / Medusa DCA Counterbore Print Set

User-requested fixes from V16:
1) Main Plate outer four corners are no longer sharp: planar corner radius R12 mm.
2) Other exposed part outlines were also audited and rounded where useful:
   - X carriage plan corners R6
   - Fixed Y plate upper corners R8
   - DCA moving body outer corners R6
   - IR camera tab top corners R4
   - Chin base R8 / rectangular column R6
3) 03 Y guide rails are rebuilt as one continuous feature, exactly flush with the fixed plate:
   rail Z = 8.0..245.0 mm; wall Z = 8.0..245.0 mm; top/bottom gap = 0.0 mm.
4) Chin support is no longer Y-shaped. It is a simple rectangular pedestal:
   100×70×8 base + 68×38 straight cuboid column, with an open-top cylindrical chin trough.
   Trough radius = 33 mm, depth = 14 mm. There is no suspended top shelf.
5) DCA mounting holes now copy the validated Medusa R64 stepped-hole style:
   Ø3.50 mm through + Ø7.80 mm counterbore, counterbore depth 5.50 mm from DCA-facing side.
   Plate thickness = 8 mm, leaving 2.50 mm at the back.
   DCA pattern remains 76.303×56.896 mm.
6) IR camera mounting interface is also restored to the previously validated original interface:
   Ø2.40 mm, 34.15 mm C-C, camera tab thickness 5.00 mm.
7) Y lock screw centers on the DCA plate are moved from local Z 30/80 to 24/74 mm.
   This fixes a V16 issue: at Y=+40 mm the upper screw is now at global Z=240 mm and remains inside the fixed plate slot.

Formal printable parts:
01_MAIN_PLATE_V17_R12_X_RAILS_FLAT_PRINT.stl
02_CHIN_SUPPORT_V17_RECTANGULAR_CRADLE_PRINT.stl
03_X_CARRIAGE_FIXED_Y_PLATE_V17_WALL_FLAT_PRINT.stl
04_DCA_MOVING_PLATE_V17_FRONT_DOWN_FLAT_PRINT.stl

Recommended first print:
00_GUIDE_FIT_COUPON_V17.stl
